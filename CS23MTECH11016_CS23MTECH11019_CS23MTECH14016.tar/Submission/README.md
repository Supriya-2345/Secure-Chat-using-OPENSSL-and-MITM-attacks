
# Secure Chat Application

A Secure Chat Application built using DTLS over UDP in C language.


## Features

- Enables two peers to exchange chat messages
- Uses Client Server architecture for establishing connection
- Makes use of control messages to start and end the session
- Allows the peers to send two or more consecutive messages before receiving a reply
- Guarantees end-to-end encryption and fast delivery of the chat messages


## Weaknesses and Vulnerabilities

- Does not guarantee reliable transfer of chat messages
- Does not handle packet losses of chat messages in a lossy environment
- Vulnerable to Downgrade attack and MITM attack with DNS spoofing


## Pre-running Installations

Install the below listed libraries before running. The below commands assume Linux Ubuntu.

```bash
sudo apt-get update
```
```bash
sudo apt-get install openssl
```
```bash
sudo apt-get install libssl-dev
```


## Run Locally

Refer to the README.md files of Alice1, Bob1 and Trudy1 for running their respective source codes.