<h1> Instructions for Bob1.com </h1>

<h2>🛠️ Execution Steps:</h2>

<p>1. Login into the Bob1 from one terminal using the command:</p>

```shell
lxc exec bob1 bash
```

<p>2. Compile the program using the command:</p>

```shell
gcc secure_chat_app.c -o secure_chat_app -lssl -lcrypto
```

<p>3a. Run the program as Server using the command:</p>

```shell
./secure_chat_app -s
```

<p>3b. Run the program as Client using the command:</p>

```shell
./secure_chat_app -c alice1
```

<p>4. End the chat session using the message:</p>

```shell
exit
```